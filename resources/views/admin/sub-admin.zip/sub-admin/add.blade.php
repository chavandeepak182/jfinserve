@extends('layouts.admin-app')
@section('content')
<div class="content-wrapper">

  <div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
      <div class="row breadcrumbs-top">
        <div class="col-12">
          <h2 class="content-header-title float-left mb-0">Event</h2>
          <div class="breadcrumb-wrapper col-12">
            <ol class="breadcrumb">

              <li class="breadcrumb-item">
                <a href="#"> Home </a>
              </li>
              <li class="breadcrumb-item">
                <a href="#"> Event </a>
              </li>
              <li class="breadcrumb-item">
              Add                                </li>
            </ol> 
          </div>
        </div>
      </div>
    </div>

  </div>                    
  <div class="content-body">

    <!-- Simple Validation start -->
    <section class="simple-validation">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4 class="card-title">Event</h4>
            </div>
            <div class="card-content">
              <div class="card-body">
                <p class="mt-1">Add <code>Event</code></p>



                <!-- Multiple Rule Validation end -->
                <form class="form-horizontal" role="form" method="POST" action="add" enctype="multipart/form-data" novalidate="">
                  <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">                        
                  <div class="contact-form">
                    <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('event_title') ? ' has-error' : '' }}">
                        <div class="form-group">
                          <div class="controls">
                           <select class="select-form country_select " required=""  name="category_id">
                            <option value="" selected="">Select Category</option>
                            @foreach($categories as $category)
                            <option value="{{$category->category_id}}">{{$category->category_name}}</option>
                           @endforeach

                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('event_title') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="event_title" value="{{ old('event_title') }}" placeholder="Event Title">
                          @if ($errors->has('event_title'))
                          <span class="help-block">
                            <strong>{{ $errors->first('event_title') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('event_date') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="date" name="event_date" value="{{ old('event_date') }}" placeholder="Event Start Date">
                          @if ($errors->has('event_date'))
                          <span class="help-block">
                            <strong>{{ $errors->first('event_date') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('event_end_date') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="date" name="event_end_date" value="{{ old('event_end_date') }}" placeholder="Event End Date">
                          @if ($errors->has('event_end_date'))
                          <span class="help-block">
                            <strong>{{ $errors->first('event_end_date') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('event_date') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="time" name="event_time" value="{{ old('event_time') }}" placeholder="Event Time">
                          @if ($errors->has('event_time'))
                          <span class="help-block">
                            <strong>{{ $errors->first('event_time') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('event_date') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="event_location" value="{{ old('event_location') }}" placeholder="Event Location">
                          @if ($errors->has('event_location'))
                          <span class="help-block">
                            <strong>{{ $errors->first('event_location') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('target') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="target" value="{{ old('target') }}" placeholder="Event Title">
                          @if ($errors->has('target'))
                          <span class="help-block">
                            <strong>{{ $errors->first('target') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="form-group mg-b-0 mg-md-l-20 mg-t-20 mg-md-t-0">
                      <img class="image-size"  src="{{config('app.baseURL')}}/images/preview.png" id="event_image" alt="" style="height: 100px;">
                    </div><!-- form-group -->
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('image') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input type="file" class="form-control" required="" data-validation-required-message="This field is required" name="image" accept="image/*" onchange="document.getElementById('event_image').src = window.URL.createObjectURL(this.files[0])" style="padding-top: 10px;">
                          @if ($errors->has('image'))
                          <span class="help-block">
                            <strong>{{ $errors->first('image') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('participation_fee') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="number" name="participation_fee" value="{{ old('participation_fee') }}" placeholder="Participation Fee">
                          @if ($errors->has('participation_fee'))
                          <span class="help-block">
                            <strong>{{ $errors->first('participation_fee') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                    <!-- full Editor start -->

                    <section class="full-editor">
                      <div class="row">
                        <div class="col-12">
                          <div class="card">

                            <div class="card-content collapse show">
                              <div class="card-body">
                                <div class="row">
                                  <div class="col-sm-12">
                                    <div id="full-wrapper">
                                      <div id="full-container">
                                        <div class="editor">

                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>


                    <textarea name="event_description" class="form-control new-editor" style="display: none;"  rows="5" value="{{ old('event_description') }}" placeholder="Enter Event description">{{old('event_description')}}</textarea>
                    @if ($errors->has('event_description'))
                    <span class="help-block">
                      <strong>{{ $errors->first('event_description') }}</strong>
                    </span>
                    @endif

                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('url') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="url" value="{{ old('url') }}" placeholder="Event URL">
                          @if ($errors->has('url'))
                          <span class="help-block">
                            <strong>{{ $errors->first('url') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('seo_title') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="seo_title" value="{{ old('seo_title') }}" placeholder="SEO Title">
                          @if ($errors->has('seo_title'))
                          <span class="help-block">
                            <strong>{{ $errors->first('seo_title') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('seo_keywords') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="seo_keywords" value="{{ old('seo_keywords') }}" placeholder="SEO Keywords">
                          @if ($errors->has('seo_keywords'))
                          <span class="help-block">
                            <strong>{{ $errors->first('seo_keywords') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>

                    <div class="col-lg-12 col-md-12 col-sm-6 {{ $errors->has('description') ? ' has-error' : '' }}">
                      <div class="form-group">
                        <div class="controls">

                          <input class="form-control" required="" data-validation-required-message="This field is required" type="text" name="seo_description" value="{{ old('description') }}" placeholder="SEO Description">
                          @if ($errors->has('description'))
                          <span class="help-block">
                            <strong>{{ $errors->first('description') }}</strong>
                          </span>
                        @endif</div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="form-submit mt-10 mb-30 text-center">

                       <button type="submit" class="btn btn-primary">Add Event</button>
                     </div>
                   </div>
                 </div>
               </div> 
             </form>
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>
</div>
</div>

<script>
  $(".editor").on('keyup  mouseover',function(e) {
    var myEditor = document.querySelector('.editor')
    var html = myEditor.children[0].innerHTML;
    $('.new-editor').val(html);
  });

  @if(Session::has('message'))
  var type = "{{ Session::get('alert-type', 'info') }}";
  switch(type){
    case 'info':
    toastr.info("{{ Session::get('message') }}");
    break;

    case 'warning':
    toastr.warning("{{ Session::get('message') }}");
    break;
    case 'success':
    toastr.success("{{ Session::get('message') }}");
    break;
    case 'error':
    toastr.error("{{ Session::get('message') }}");
    break;
  }
  @endif

</script>
@endsection